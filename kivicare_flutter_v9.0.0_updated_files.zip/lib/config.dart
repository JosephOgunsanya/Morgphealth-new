const APP_NAME = 'KiviCare';
const APP_NAME = 'KiviCare';
const APP_FIRST_NAME = 'Kivi';
const APP_SECOND_NAME = 'Care';
const APP_NAME_TAG_LINE = 'Clinic and Patient Management App';


const DOMAIN_URL = '';



const BASE_URL = '$DOMAIN_URL/wp-json/';

const IQONIC_PACKAGE_NAME = "com.iqonic.kivicare"; // Do not change this Package Name.
const DEFAULT_LANGUAGE = 'en';
var COPY_RIGHT_TEXT = '© ${DateTime.now().year}. Made with ♡ by Iqonic Design';

const TERMS_AND_CONDITION_URL = '';
const PRIVACY_POLICY_URL = '';
const SUPPORT_URL = '';
const CODE_CANYON_URL = "";
const MAIL_TO = "";

const ONESIGNAL_APP_ID = '' //Your ONESIGNAL_APP_ID ;
const ONESIGNAL_REST_API_ID = '' //ONESIGNAL_REST_API_ID;
const ONESIGNAL_CHANNEL_ID = '' //Your ONESIGNAL_CHANNEL_ID;

const STRIPE_CURRENCY_CODE = 'INR';
const STRIPE_MERCHANT_COUNTRY_CODE = 'IN';

const STRIPE_TEST_SECRET_KEY = '';
const STRIPE_TEST_PUBLIC_KEY = '';
const STRIPE_URL = 'https://api.stripe.com/v1/payment_intents';

const CONSUMER_KEY = '';
const CONSUMER_SECRET = '';



// Pagination
const PER_PAGE = 20;
